# foodmgt
[![CI/CD Pipeline](https://github.com/david-inusah/foodmgt/actions/workflows/ci-cd.yml/badge.svg?branch=master)](https://github.com/david-inusah/foodmgt/actions/workflows/ci-cd.yml)

Genkey Food Management App
