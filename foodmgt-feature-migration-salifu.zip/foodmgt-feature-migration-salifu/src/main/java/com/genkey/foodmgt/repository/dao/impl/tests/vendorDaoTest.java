/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.genkey.foodmgt.repository.dao.impl.tests;

import com.genkey.foodmgt.model.impl.Vendor;
//import com.genkey.foodmgt.repository.dao.impl.VendorDAOImpl;

/**
 *
 * @author david
 */
public class vendorDaoTest {
    public static void main (String []args){
       // VendorDAOImpl vendor = new VendorDAOImpl();
        
   // System.out.println(vendor.getActiveVendor(Vendor.class).toString());
    }
}
