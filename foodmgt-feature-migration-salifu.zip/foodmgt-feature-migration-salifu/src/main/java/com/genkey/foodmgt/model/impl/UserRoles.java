package com.genkey.foodmgt.model.impl;

public enum UserRoles {
    ADMIN,
    USER,
    INTERN,
    NSS,
    SECURITY
}
