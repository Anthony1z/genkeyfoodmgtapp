package com.genkey.foodmgt.util;

public enum Days {
    Monday,Tuesday, Wednesday,Thursday, Friday
}
