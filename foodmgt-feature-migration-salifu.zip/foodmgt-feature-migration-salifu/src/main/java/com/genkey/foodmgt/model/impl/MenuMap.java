package com.genkey.foodmgt.model.impl;

public class MenuMap {
    //another approach to saving the menumap to the db
//    @ElementCollection(fetch=FetchType.EAGER)
//    @CollectionTable(name = "menu_map", joinColumns = @JoinColumn(name = "person_id"))
//    @MapKeyColumn(name = "name")
//    @OrderColumn(name = "name")
//    @Column(name = "pet")
//    private Map<String, String> pets = new LinkedHashMap<String, String>();
}
