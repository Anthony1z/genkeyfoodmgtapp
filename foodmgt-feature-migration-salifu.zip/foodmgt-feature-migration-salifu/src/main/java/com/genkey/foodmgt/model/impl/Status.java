package com.genkey.foodmgt.model.impl;

public enum Status {
    PENDING,
    RECEIVED
}
