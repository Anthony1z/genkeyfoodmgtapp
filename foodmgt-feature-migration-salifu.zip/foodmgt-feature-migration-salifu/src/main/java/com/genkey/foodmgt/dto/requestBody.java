package com.genkey.foodmgt.dto;

import lombok.Data;

import java.util.List;

@Data
public class requestBody {
    private String day;

    private String value;
}
