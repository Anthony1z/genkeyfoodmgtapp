package com.genkey.foodmgt.dto;

public class foodByDays {

    private String food;

    public foodByDays(String food) {
        this.food = food;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }
}
